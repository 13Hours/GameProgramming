import javax.swing.JFrame;

public class GameViewer {

	public static void main (String[] args) {

		JFrame gameFrame = new GameFrame ();

	}
}